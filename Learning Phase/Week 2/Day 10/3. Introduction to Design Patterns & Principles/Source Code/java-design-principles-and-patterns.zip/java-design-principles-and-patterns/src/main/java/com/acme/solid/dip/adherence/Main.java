package com.acme.solid.dip.adherence;

//Scenario 2: Adherence to DIP
//Now, let's refactor the code to adhere to the Dependency Inversion Principle by introducing an abstraction
// (PaymentMethod) that both PaymentService and the concrete payment classes (CreditCardPayment and PayPalPayment)
// depend on.

//Adherence to DIP:
//We have introduced the PaymentMethod interface as an abstraction for different payment methods.
//The PaymentService class now depends on the PaymentMethod abstraction rather than on concrete classes like
// CreditCardPayment.
//The specific payment methods (CreditCardPayment and PayPalPayment) implement the PaymentMethod interface,
//so they can be injected into the PaymentService class.
//We can easily switch payment methods without changing the PaymentService class. This demonstrates adherence
// to the Dependency Inversion Principle because the high-level PaymentService depends on an abstraction,
// and the low-level modules (CreditCardPayment, PayPalPayment) depend on that abstraction as well.

// PaymentMethod interface defines an abstraction for payment methods
interface PaymentMethod {
    void pay();
}

// Concrete implementation of CreditCardPayment
class CreditCardPayment implements PaymentMethod {
    @Override
    public void pay() {
        System.out.println("Payment made using Credit Card.");
    }
}

// Concrete implementation of PayPalPayment
class PayPalPayment implements PaymentMethod {
    @Override
    public void pay() {
        System.out.println("Payment made using PayPal.");
    }
}

// High-level module: PaymentService now depends on the abstraction PaymentMethod (adheres to DIP)
class PaymentService {
    private PaymentMethod paymentMethod;

    // Constructor injection for dependency
    public PaymentService(PaymentMethod paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public void processPayment() {
        paymentMethod.pay();
    }
}

public class Main {
    public static void main(String[] args) {
        // Now we can inject any payment method, demonstrating adherence to DIP
        PaymentMethod creditCardPayment = new CreditCardPayment();
        PaymentService paymentService = new PaymentService(creditCardPayment);
        paymentService.processPayment();  // Payment made using Credit Card.

        // We can easily switch to another payment method without modifying PaymentService
        PaymentMethod paypalPayment = new PayPalPayment();
        paymentService = new PaymentService(paypalPayment);
        paymentService.processPayment();  // Payment made using PayPal.
    }
}
