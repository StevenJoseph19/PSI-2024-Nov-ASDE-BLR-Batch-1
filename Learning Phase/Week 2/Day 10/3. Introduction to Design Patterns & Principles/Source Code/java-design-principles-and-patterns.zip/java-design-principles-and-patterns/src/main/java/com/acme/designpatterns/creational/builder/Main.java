package com.acme.designpatterns.creational.builder;


public class Main {
    public static void main(String[] args) {
        // Using the Builder to create a Car object
        Car car = new Car.CarBuilder("Toyota", "Camry") // Required parameters
                .setColor("Red")                      // Optional parameter
                .setYear(2024)                        // Optional parameter
                .setSunroof(true)                     // Optional parameter
                .build();                             // Build the final object

        // Print the Car details
        System.out.println(car);
    }
}

// The Product Class (Car)
class Car {
    // Required parameters
    private final String brand;
    private final String model;

    // Optional parameters
    private final String color;
    private final int year;
    private final boolean sunroof;

    // Private Constructor accessible only through the Builder
    private Car(CarBuilder builder) {
        this.brand = builder.brand;
        this.model = builder.model;
        this.color = builder.color;
        this.year = builder.year;
        this.sunroof = builder.sunroof;
    }

    // Static nested Builder Class
    public static class CarBuilder {
        // Required parameters
        private final String brand;
        private final String model;

        // Optional parameters with default values
        private String color = "White";
        private int year = 2020;
        private boolean sunroof = false;

        // Builder constructor for required fields
        public CarBuilder(String brand, String model) {
            this.brand = brand;
            this.model = model;
        }

        // Builder methods for optional fields
        public CarBuilder setColor(String color) {
            this.color = color;
            return this;
        }

        public CarBuilder setYear(int year) {
            this.year = year;
            return this;
        }

        public CarBuilder setSunroof(boolean sunroof) {
            this.sunroof = sunroof;
            return this;
        }

        // Build method to create the Car object
        public Car build() {
            return new Car(this);
        }
    }

    // Overriding toString for printing details
    @Override
    public String toString() {
        return "Car [Brand=" + brand + ", Model=" + model + ", Color=" + color
                + ", Year=" + year + ", Sunroof=" + sunroof + "]";
    }
}
