//Remote Control System
//We will create a system where a remote control can execute different commands like turning on/off lights and fans.

package com.acme.designpatterns.behavioural.command;

// Command Interface
interface Command {
    void execute();
}

// Receiver 1: Light
class Light {
    public void turnOn() {
        System.out.println("The light is ON");
    }

    public void turnOff() {
        System.out.println("The light is OFF");
    }
}

// Receiver 2: Fan
class Fan {
    public void start() {
        System.out.println("The fan is spinning");
    }

    public void stop() {
        System.out.println("The fan is stopped");
    }
}

// Concrete Command 1: Turn On Light
class LightOnCommand implements Command {
    private Light light;

    public LightOnCommand(Light light) {
        this.light = light;
    }

    @Override
    public void execute() {
        light.turnOn();
    }
}

// Concrete Command 2: Turn Off Light
class LightOffCommand implements Command {
    private Light light;

    public LightOffCommand(Light light) {
        this.light = light;
    }

    @Override
    public void execute() {
        light.turnOff();
    }
}

// Concrete Command 3: Start Fan
class FanStartCommand implements Command {
    private Fan fan;

    public FanStartCommand(Fan fan) {
        this.fan = fan;
    }

    @Override
    public void execute() {
        fan.start();
    }
}

// Concrete Command 4: Stop Fan
class FanStopCommand implements Command {
    private Fan fan;

    public FanStopCommand(Fan fan) {
        this.fan = fan;
    }

    @Override
    public void execute() {
        fan.stop();
    }
}

// Invoker: Remote Control
class RemoteControl {
    private Command command;

    public void setCommand(Command command) {
        this.command = command;
    }

    public void pressButton() {
        if (command == null) {
            System.out.println("No command assigned to this button.");
        } else {
            command.execute();
        }
    }
}

// Main Class (Client)
public class Main {
    public static void main(String[] args) {
        // Receivers
        Light livingRoomLight = new Light();
        Fan ceilingFan = new Fan();

        // Commands
        Command lightOn = new LightOnCommand(livingRoomLight);
        Command lightOff = new LightOffCommand(livingRoomLight);
        Command fanStart = new FanStartCommand(ceilingFan);
        Command fanStop = new FanStopCommand(ceilingFan);

        // Invoker
        RemoteControl remote = new RemoteControl();

        // Test the remote with light commands
        remote.setCommand(lightOn);
        remote.pressButton();

        remote.setCommand(lightOff);
        remote.pressButton();

        // Test the remote with fan commands
        remote.setCommand(fanStart);
        remote.pressButton();

        remote.setCommand(fanStop);
        remote.pressButton();
    }
}

