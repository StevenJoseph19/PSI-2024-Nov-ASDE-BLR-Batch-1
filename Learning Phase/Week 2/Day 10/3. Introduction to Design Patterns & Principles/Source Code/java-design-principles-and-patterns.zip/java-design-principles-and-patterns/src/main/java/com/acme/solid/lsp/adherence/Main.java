package com.acme.solid.lsp.adherence;
//Scenario 2: Adherence to LSP
//Now let's refactor the example to adhere to the Liskov Substitution Principle. Instead of forcing all Bird objects
// to have a fly() method, we will introduce an interface for birds that can fly and separate out the flying behavior
// into a FlyingBird class.
//Adherence to LSP:
//The Bird class is now a general class that doesn't enforce all birds to be able to fly.
//Flyable is a separate interface that only birds capable of flying, like the Sparrow, implement.
//The Penguin class no longer inherits an unnecessary fly() method, and it doesn’t break any expected behavior of the
// Bird class.
//The Penguin can now be substituted for Bird without causing any issues, adhering to the Liskov Substitution Principle.

// Interface for flying birds
interface Flyable {
    void fly();
}

// Superclass: Bird (doesn't force all birds to fly)
class Bird {
    public void eat() {
        System.out.println("Eating...");
    }
}

// Subclass: Sparrow (flying bird)
class Sparrow extends Bird implements Flyable {
    @Override
    public void fly() {
        System.out.println("Sparrow is flying...");
    }
}

// Subclass: Penguin (non-flying bird, no fly method)
class Penguin extends Bird {
    public void swim() {
        System.out.println("Penguin is swimming...");
    }
}

public class Main {
    public static void main(String[] args) {
        // Using Bird reference
        Bird bird = new Sparrow();
        bird.eat(); // Eating
        ((Flyable) bird).fly(); // Sparrow is flying...

        // Using Penguin reference, which adheres to LSP
        Bird penguin = new Penguin();
        penguin.eat(); // Eating
        // No need to call fly method, penguin doesn't have it
    }
}
