package com.acme.solid.dip.violation;
//Scenario 1: Violation of DIP
//In this example, we will demonstrate a violation of the Dependency Inversion Principle.
// The PaymentService class directly depends on a concrete CreditCardPayment class, which violates the principle
// as the high-level module (PaymentService) is tightly coupled with the low-level module (CreditCardPayment).
//Violation of DIP:
//The PaymentService class directly creates and depends on the CreditCardPayment class, which means it is tightly
// coupled to this specific payment method.
//If we wanted to add other payment methods (e.g., PayPalPayment), we would need to modify the PaymentService class,
// violating the Dependency Inversion Principle.

// PaymentService class directly depends on CreditCardPayment (violates DIP)
class CreditCardPayment {
    public void pay() {
        System.out.println("Payment made using Credit Card.");
    }
}

// High-level module: PaymentService depends directly on the low-level CreditCardPayment class.
class PaymentService {
    private CreditCardPayment creditCardPayment;

    public PaymentService() {
        // Directly creating the dependency (violates DIP)
        creditCardPayment = new CreditCardPayment();
    }

    public void processPayment() {
        creditCardPayment.pay();
    }
}

public class Main {
    public static void main(String[] args) {
        PaymentService paymentService = new PaymentService();
        paymentService.processPayment();  // Payment made using Credit Card.
    }
}
