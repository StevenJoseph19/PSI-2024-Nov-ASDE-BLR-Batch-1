package com.acme.designpatterns.creational.singleton;

// File Name: Main.java
public class Main {
    public static void main(String[] args) {
        // Try to get the Singleton instance multiple times
        Singleton singleton1 = Singleton.getInstance();
        Singleton singleton2 = Singleton.getInstance();

        // Show messages from the Singleton instance
        singleton1.showMessage();

        // Check if both references point to the same instance
        if (singleton1 == singleton2) {
            System.out.println("Both instances are the same!");
        } else {
            System.out.println("Different instances exist!");
        }
    }
}

// Singleton Class
class Singleton {
    // Private static variable of the single instance
    private static Singleton instance;

    // Private constructor to restrict instantiation from outside
    private Singleton() {
        System.out.println("Singleton Instance Created!");
    }

    // Public method to provide access to the single instance
    public static Singleton getInstance() {
        if (instance == null) {
            instance = new Singleton(); // Create the instance if it doesn't exist
        }
        return instance; // Return the single instance
    }

    // Example method for demonstration
    public void showMessage() {
        System.out.println("Hello from Singleton!");
    }
}
