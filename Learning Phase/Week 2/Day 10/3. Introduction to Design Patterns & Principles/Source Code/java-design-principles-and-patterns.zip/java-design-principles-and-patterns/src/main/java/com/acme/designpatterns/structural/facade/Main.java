package com.acme.designpatterns.structural.facade;
//Scenario:
//You have multiple components in a home theater system (e.g., TV, SoundSystem, Projector) that must be configured
// and used in a specific sequence.
//The Facade simplifies this by providing a unified interface.

// File Name: Main.java
public class Main {
    public static void main(String[] args) {
        // Create the Facade
        HomeTheaterFacade homeTheater = new HomeTheaterFacade();

        // Use the Facade to control the system
        System.out.println("Setting up Movie Night:");
        homeTheater.startMovie();

        System.out.println("\nShutting down Movie Night:");
        homeTheater.endMovie();
    }
}

// The Facade Class
class HomeTheaterFacade {
    private TV tv;
    private SoundSystem soundSystem;
    private Projector projector;

    // Constructor initializes components
    public HomeTheaterFacade() {
        this.tv = new TV();
        this.soundSystem = new SoundSystem();
        this.projector = new Projector();
    }

    // Simplified method to start a movie
    public void startMovie() {
        projector.turnOn();
        projector.setInput("HDMI 1");
        tv.turnOn();
        tv.setStreamingApp("Netflix");
        soundSystem.turnOn();
        soundSystem.setVolume(20);
        System.out.println("Movie is ready to watch!");
    }

    // Simplified method to end a movie
    public void endMovie() {
        tv.turnOff();
        soundSystem.turnOff();
        projector.turnOff();
        System.out.println("Movie night ended!");
    }
}

// Subsystem: TV
class TV {
    public void turnOn() {
        System.out.println("TV is turned ON.");
    }

    public void turnOff() {
        System.out.println("TV is turned OFF.");
    }

    public void setStreamingApp(String app) {
        System.out.println("TV set to stream from " + app + ".");
    }
}

// Subsystem: SoundSystem
class SoundSystem {
    public void turnOn() {
        System.out.println("SoundSystem is turned ON.");
    }

    public void turnOff() {
        System.out.println("SoundSystem is turned OFF.");
    }

    public void setVolume(int level) {
        System.out.println("SoundSystem volume set to " + level + ".");
    }
}

// Subsystem: Projector
class Projector {
    public void turnOn() {
        System.out.println("Projector is turned ON.");
    }

    public void turnOff() {
        System.out.println("Projector is turned OFF.");
    }

    public void setInput(String input) {
        System.out.println("Projector input set to " + input + ".");
    }
}

