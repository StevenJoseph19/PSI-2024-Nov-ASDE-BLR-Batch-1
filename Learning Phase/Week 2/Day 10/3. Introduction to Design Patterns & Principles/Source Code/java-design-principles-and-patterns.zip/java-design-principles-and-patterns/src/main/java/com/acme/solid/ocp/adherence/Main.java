package com.acme.solid.ocp.adherence;
//Scenario 2: Adherence to OCP
//In this example, we'll adhere to OCP by using inheritance and polymorphism to handle tax calculations,
//so we can easily add new product types without modifying the existing code.
//Adherence to OCP:
//We created an interface Taxable that defines a calculateTax() method.
//Each product type (Electronics, Food, Clothes) implements the Taxable interface and provides its own implementation
//        of the calculateTax() method.
//The TaxCalculator class does not need to be modified to add new product types. We can simply create new classes
//that implement the Taxable interface.
//If we need to add more product types (e.g., books, toys), we can do so by creating new classes that implement
//Taxable without changing the existing code in the TaxCalculator class.

// Interface representing a Taxable entity
interface Taxable {
    double calculateTax();
}

// Class for Electronics product
class Electronics implements Taxable {
    private double price;

    public Electronics(double price) {
        this.price = price;
    }

    @Override
    public double calculateTax() {
        return price * 0.18;  // 18% tax for Electronics
    }
}

// Class for Food product
class Food implements Taxable {
    private double price;

    public Food(double price) {
        this.price = price;
    }

    @Override
    public double calculateTax() {
        return price * 0.05;  // 5% tax for Food
    }
}

// New Product type: Clothes
class Clothes implements Taxable {
    private double price;

    public Clothes(double price) {
        this.price = price;
    }

    @Override
    public double calculateTax() {
        return price * 0.10;  // 10% tax for Clothes
    }
}

// TaxCalculator class remains unchanged
class TaxCalculator {
    // Method to calculate tax for any taxable product
    public double calculateTax(Taxable taxable) {
        return taxable.calculateTax();
    }
}

public class Main {
    public static void main(String[] args) {
        // Creating different types of products
        Taxable electronics = new Electronics(1000);
        Taxable food = new Food(200);
        Taxable clothes = new Clothes(500);

        TaxCalculator taxCalculator = new TaxCalculator();
        System.out.println("Electronics Tax: " + taxCalculator.calculateTax(electronics));
        System.out.println("Food Tax: " + taxCalculator.calculateTax(food));
        System.out.println("Clothes Tax: " + taxCalculator.calculateTax(clothes));
    }
}
