package com.acme.solid.lsp.violation;

//Scenario 1: Violation of LSP
//In this example, we'll demonstrate a violation of the Liskov Substitution Principle.
//We have a Bird superclass and a Penguin subclass, but Penguin cannot fly,
//which breaks the behavior expected from the Bird class.
//Violation of LSP:
//In the below code, the Penguin subclass inherits from the Bird superclass and overrides the fly() method.
// However, since penguins cannot fly, throwing an exception in the fly() method causes a violation of LSP.
// Replacing a Bird object with a Penguin object breaks the expected behavior of the program, as it now throws an
// exception instead of flying.
// Superclass: Bird
class Bird {
    public void fly() {
        System.out.println("Flying...");
    }
}

// Subclass: Penguin (violation of LSP)
class Penguin extends Bird {
    // Penguin cannot fly, so overriding the fly method creates an issue
    @Override
    public void fly() {
        throw new UnsupportedOperationException("Penguins cannot fly!");
    }
}

public class Main {
    public static void main(String[] args) {
        // Using Bird reference
        Bird bird = new Bird();
        bird.fly(); // Flying

        // Using Penguin reference, which breaks LSP
        Bird penguin = new Penguin();
        penguin.fly(); // Throws UnsupportedOperationException
    }
}
