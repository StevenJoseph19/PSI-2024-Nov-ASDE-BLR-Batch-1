package com.acme.solid.isp.adherence;

//Scenario 2: Adherence to ISP
//Now let's refactor the example to adhere to the Interface Segregation Principle by creating smaller,
//more specific interfaces.

// Adhering to Interface Segregation Principle
// Separate interfaces for different responsibilities
//The Worker interface now only contains the work() method, which is relevant to all worker types.
//The Eater interface is introduced for classes that need to implement eating behavior.
//The Manager class implements both Worker and Eater, as it needs both work() and eat() functionalities.
//The Robot class only implements the Worker interface, as it doesn't need to eat.
//This design adheres to the Interface Segregation Principle, as each class only implements the interfaces that are
// relevant to its behavior, and no class is forced to implement unnecessary methods.

// Basic Worker interface for general working behavior
interface Worker {
    void work();
}

// Eating behavior interface for classes that need it
interface Eater {
    void eat();
}

// Class: Manager
// A manager works and eats, so it implements both Worker and Eater
class Manager implements Worker, Eater {
    @Override
    public void work() {
        System.out.println("Managing team...");
    }

    @Override
    public void eat() {
        System.out.println("Manager is eating in the office cafeteria...");
    }
}

// Class: Robot
// A robot works but doesn't need to eat, so it only implements Worker
class Robot implements Worker {
    @Override
    public void work() {
        System.out.println("Robot working...");
    }
}

public class Main {
    public static void main(String[] args) {
        Worker manager = new Manager();
        manager.work();
        ((Eater) manager).eat();  // Manager is also an Eater

        Worker robot = new Robot();
        robot.work();
        // No need to call eat() for robot since it doesn't implement the Eater interface
    }
}
