package com.acme.designpatterns.behavioural.strategy;

// Strategy Interface
interface PaymentStrategy {
    void pay(double amount);
}

// Concrete Strategy 1: PayPal Payment
class PayPalPayment implements PaymentStrategy {
    private String email;

    public PayPalPayment(String email) {
        this.email = email;
    }

    @Override
    public void pay(double amount) {
        System.out.println("Paid $" + amount + " using PayPal account: " + email);
    }
}

// Concrete Strategy 2: Credit Card Payment
class CreditCardPayment implements PaymentStrategy {
    private String cardNumber;

    public CreditCardPayment(String cardNumber) {
        this.cardNumber = cardNumber;
    }

    @Override
    public void pay(double amount) {
        System.out.println("Paid $" + amount + " using Credit Card: " + cardNumber);
    }
}

// Concrete Strategy 3: Bank Transfer Payment
class BankTransferPayment implements PaymentStrategy {
    private String bankAccount;

    public BankTransferPayment(String bankAccount) {
        this.bankAccount = bankAccount;
    }

    @Override
    public void pay(double amount) {
        System.out.println("Paid $" + amount + " using Bank Account: " + bankAccount);
    }
}

// Context Class
class PaymentProcessor {
    private PaymentStrategy paymentStrategy;

    // Allows the strategy to be set dynamically
    public void setPaymentStrategy(PaymentStrategy paymentStrategy) {
        this.paymentStrategy = paymentStrategy;
    }

    public void processPayment(double amount) {
        if (paymentStrategy == null) {
            throw new IllegalStateException("Payment strategy not set!");
        }
        paymentStrategy.pay(amount);
    }
}

// Main Class (Client)
public class Main {
    public static void main(String[] args) {
        PaymentProcessor processor = new PaymentProcessor();

        // Use PayPal Payment
        processor.setPaymentStrategy(new PayPalPayment("user@example.com"));
        processor.processPayment(100.50);

        // Use Credit Card Payment
        processor.setPaymentStrategy(new CreditCardPayment("1234-5678-9876-5432"));
        processor.processPayment(200.75);

        // Use Bank Transfer Payment
        processor.setPaymentStrategy(new BankTransferPayment("BANK-987654321"));
        processor.processPayment(300.00);
    }
}
