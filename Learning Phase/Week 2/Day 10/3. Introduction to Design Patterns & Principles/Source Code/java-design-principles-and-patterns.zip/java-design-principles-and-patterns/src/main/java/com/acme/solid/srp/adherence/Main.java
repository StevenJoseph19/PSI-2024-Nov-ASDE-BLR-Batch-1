package com.acme.solid.srp.adherence;
//Why It Adheres to SRP
//The User class is solely responsible for managing user data.
//The UserRepository class is solely responsible for handling database operations.
//Changes to database logic will not affect the User class and vice versa.
// Adhering to SRP

// Class responsible for user data
class User {
    private String name;
    private String email;

    public User(String name, String email) {
        this.name = name;
        this.email = email;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public void displayUser() {
        System.out.println("Name: " + name + ", Email: " + email);
    }
}

// Class responsible for database operations
class UserRepository {
    public void save(User user) {
        System.out.println("Saving " + user.getName() + " to the database...");
    }
}

public class Main {
    public static void main(String[] args) {
        User user = new User("Alice", "alice@example.com");
        user.displayUser();

        UserRepository userRepository = new UserRepository();
        userRepository.save(user); // Database operation handled by a separate class
    }
}
