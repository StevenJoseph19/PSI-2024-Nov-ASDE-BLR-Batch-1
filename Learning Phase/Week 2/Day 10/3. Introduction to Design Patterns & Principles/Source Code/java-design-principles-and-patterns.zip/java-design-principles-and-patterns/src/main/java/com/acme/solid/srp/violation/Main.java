package com.acme.solid.srp.violation;

//Why It Violates SRP
//The UserManager class has two responsibilities:
//Managing user data.
//Handling database operations.
//Any change to database logic will require modifying this class, which is unrelated to its primary purpose
// (managing user data).

// SRP Violation
class UserManager {
    private String name;
    private String email;

    public UserManager(String name, String email) {
        this.name = name;
        this.email = email;
    }

    // Handles user data
    public void displayUser() {
        System.out.println("Name: " + name + ", Email: " + email);
    }

    // Handles database operations
    public void saveToDatabase() {
        System.out.println("Saving " + name + " to the database...");
    }
}

public class Main {
    public static void main(String[] args) {
        UserManager user = new UserManager("Alice", "alice@example.com");
        user.displayUser();
        user.saveToDatabase(); // Database operation in the same class
    }
}
