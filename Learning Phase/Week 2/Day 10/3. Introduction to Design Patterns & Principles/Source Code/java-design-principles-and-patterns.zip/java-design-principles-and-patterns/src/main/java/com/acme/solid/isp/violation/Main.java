package com.acme.solid.isp.violation;
//Scenario 1: Violation of ISP
//In this scenario, we will demonstrate a violation of the Interface Segregation Principle. We have a Worker interface
//that has multiple methods that aren't relevant to all implementing classes.
//The Worker interface forces both Manager and Robot classes to implement the eat() method, which is not applicable for
// all types of workers.
//The Robot is forced to implement an eat() method, even though it has no use for it. This violates the
// Interface Segregation Principle because the Robot class is forced to implement an unnecessary method.

// Violating Interface Segregation Principle
// Worker interface has too many responsibilities
interface Worker {
    void work();
    void eat();
}

// Class: Manager
// A manager works but doesn't eat in the same way a regular worker does
class Manager implements Worker {
    @Override
    public void work() {
        System.out.println("Managing team...");
    }

    @Override
    public void eat() {
        // Managers may eat, but they have different needs from other workers
        System.out.println("Manager is eating in the office cafeteria...");
    }
}

// Class: Robot
// A robot works but doesn't need to eat, so it is forced to implement an unnecessary method
class Robot implements Worker {
    @Override
    public void work() {
        System.out.println("Robot working...");
    }

    @Override
    public void eat() {
        // Robots don't need to eat, but they're forced to implement this method
        System.out.println("Robot doesn't need to eat.");
    }
}

public class Main {
    public static void main(String[] args) {
        Worker manager = new Manager();
        manager.work();
        manager.eat();

        Worker robot = new Robot();
        robot.work();
        robot.eat(); // This is unnecessary and breaks the ISP, as robots don't need to eat
    }
}
